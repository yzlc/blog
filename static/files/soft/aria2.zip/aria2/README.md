---
title: "aria2"
date: 2019-08-20
description: ""
tags: [aria2]
---

## [aria2](https://github.com/aria2/aria2/releases)
### aria2.conf
>配置文件
### aria2.session
>任务保存文件 未完成任务会保存在这里
### startup.vbs
>运行aria2
### run.ps1
>下载aria2c.exe,添加开机启动项,运行aria2